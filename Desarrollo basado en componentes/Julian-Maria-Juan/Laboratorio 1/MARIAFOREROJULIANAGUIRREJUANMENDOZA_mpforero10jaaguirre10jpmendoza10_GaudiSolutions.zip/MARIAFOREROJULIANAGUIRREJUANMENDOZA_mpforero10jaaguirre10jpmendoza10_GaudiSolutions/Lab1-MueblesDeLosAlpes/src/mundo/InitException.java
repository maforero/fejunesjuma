/*
 * InitException actúa como un wrapper de las excepciones que se
 * presenten en el método Init de la anocación Init
 */
package mundo;

/**
 *
 * @author maria
 */
public class InitException extends RuntimeException{
    
}
